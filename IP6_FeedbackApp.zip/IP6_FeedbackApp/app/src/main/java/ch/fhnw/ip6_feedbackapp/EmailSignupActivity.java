package ch.fhnw.ip6_feedbackapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EmailSignupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_signup);
    }
}
