package ch.fhnw.ip6_feedbackapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginEmailActivity extends AppCompatActivity {
    EditText emailField;
    EditText passwordField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_email);
        emailField = (EditText) findViewById(R.id.editTextEmail);
        passwordField = (EditText) findViewById(R.id.editTextPassword);
    }

    public void setupNewAccount(View view){
        Intent i = new Intent(getApplicationContext(), EmailSignupActivity.class);
        startActivity(i);
    }
}
